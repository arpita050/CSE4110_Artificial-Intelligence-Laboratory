# -*- coding: utf-8 -*-
"""
Created on Tue Jun  4 16:34:49 2024

@author: the great Arpita
"""

import random

def initialize_population(size, chrom_length):
    population = []
    for _ in range(size):
        chromosome = ''.join(random.choice('01') for _ in range(chrom_length))
        population.append(chromosome)
    return population

def binary_to_int(binary):
    return int(binary, 2)

def fitness(chromosome):
    x = binary_to_int(chromosome)
    return x ** 2

def roulette_wheel_selection(population, fitness_values):
    total_fitness = sum(fitness_values)
    selection_probs = [f / total_fitness for f in fitness_values]
    selected_indices = random.choices(range(len(population)), weights=selection_probs, k=len(population))
    return [population[i] for i in selected_indices]

def one_point_crossover(parent1, parent2):
    point = random.randint(1, len(parent1) - 1)
    child1 = parent1[:point] + parent2[point:]
    child2 = parent2[:point] + parent1[point:]
    return child1, child2

def crossover_population(mating_pool):
    new_population = []
    for i in range(0, len(mating_pool), 2):
        parent1 = mating_pool[i]
        parent2 = mating_pool[i+1]
        child1, child2 = one_point_crossover(parent1, parent2)
        new_population.extend([child1, child2])
    return new_population

def mutate(chromosome, mutation_rate=0.01):
    mutated = ''.join(
        bit if random.random() > mutation_rate else str(1 - int(bit)) for bit in chromosome
    )
    return mutated

def mutate_population(population, mutation_rate=0.01):
    return [mutate(chrom, mutation_rate) for chrom in population]

# Parameters
population_size = 4
chrom_length = 5
mutation_rate = 0.01
num_generations = 10

# Initialize population
population = initialize_population(population_size, chrom_length)
print("Initial Population:", population)

for generation in range(num_generations):
    # Calculate fitness
    fitness_values = [fitness(chrom) for chrom in population]
    print(f"Generation {generation} Fitness Values:", fitness_values)
    
    # Selection
    mating_pool = roulette_wheel_selection(population, fitness_values)
    print(f"Generation {generation} Mating Pool:", mating_pool)
    
    # Crossover
    new_population = crossover_population(mating_pool)
    print(f"Generation {generation} New Population after Crossover:", new_population)
    
    # Mutation
    population = mutate_population(new_population, mutation_rate)
    print(f"Generation {generation} Population after Mutation:", population)

# Final results
final_fitness_values = [fitness(chrom) for chrom in population]
print("Final Population:", population)
print("Final Fitness Values:", final_fitness_values)
