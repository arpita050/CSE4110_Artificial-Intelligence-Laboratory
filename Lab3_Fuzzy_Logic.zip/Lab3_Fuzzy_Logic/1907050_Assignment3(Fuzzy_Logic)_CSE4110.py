# -*- coding: utf-8 -*-
"""
Created on Sat May 11 18:29:45 2024

@author: the great Arpita
"""
#Fuzzy Logic 1907050
import numpy as np
deg_al = {}
deg_up = {}
deg_op = {}
def getMembershipLight(x):
    global deg_al
    deg_al = {}
    if x < 0 or x > 500:
        deg_al["dark"] = 0
        deg_al["dim"] = 0
        deg_al["bright"] = 0
    elif x <= 40:
        deg_al["dark"] = 1
        deg_al["dim"] = 0
        deg_al["bright"] = 0
    elif x > 40 and x < 50:
        deg_al["dark"] = float((50 - x) / 10)
        deg_al["dim"] = float((x - 40) / 10)
        deg_al["bright"] = 0
    elif x >= 50 and x <= 100:
        deg_al["dark"] = 0
        deg_al["dim"] = 1
        deg_al["bright"] = 0
    elif x > 100 and x < 150:
        deg_al["dark"] = 0
        deg_al["dim"] = 1
        deg_al["bright"] = float((x - 100) / 50)
    else:
        deg_al["dark"] = 0
        deg_al["dim"] = 0
        deg_al["bright"] = float((500 - x) / 350)
    return deg_al
def getMembershipPreference(y):
    global deg_up
    deg_up = {}
    if y < 0 or y > 100:
        deg_up["dim"] = 0
        deg_up["low"] = 0
        deg_up["medium"] = 0
        deg_up["high"] = 0
        deg_up["bright"] = 0
    elif y >= 0 and y <= 20:
        deg_up["dim"] = 1
        deg_up["low"] = 0
        deg_up["medium"] = 0
        deg_up["high"] = 0
        deg_up["bright"] = 0
    elif y >= 20 and y <= 30:
        deg_up["dim"] = float((30 - y) / 10)
        deg_up["low"] = float((y - 20) / 10)
        deg_up["medium"] = 0
        deg_up["high"] = 0
        deg_up["bright"] = 0
    elif y > 30 and y <= 40:
        deg_up["dim"] = 0
        deg_up["low"] = 1
        deg_up["medium"] = 0
        deg_up["high"] = 0
        deg_up["bright"] = 0
    elif y > 40 and y <= 50:
        deg_up["dim"] = 0
        deg_up["low"] = float((50 - y) / 10)
        deg_up["medium"] = float((y - 40) / 10)
        deg_up["high"] = 0
        deg_up["bright"] = 0
    elif y > 50 and y <= 60:
        deg_up["dim"] = 0
        deg_up["low"] = 0
        deg_up["medium"] = 1
        deg_up["high"] = 0
        deg_up["bright"] = 0
    elif y > 60 and y <= 70:
        deg_up["dim"] = 0
        deg_up["low"] = 0
        deg_up["medium"] = float((70 - y) / 10)
        deg_up["high"] = float((y - 60) / 10)
        deg_up["bright"] = 0
    elif y > 70 and y <= 80:
        deg_up["dim"] = 0
        deg_up["low"] = 0
        deg_up["medium"] = 0
        deg_up["high"] = 1
        deg_up["bright"] = 0
    elif y > 80 and y <= 90:
        deg_up["dim"] = 0
        deg_up["low"] = 0
        deg_up["medium"] = 0
        deg_up["high"] = float((90 - y) / 10)
        deg_up["bright"] = float((y - 80) / 10)
    elif y > 90 and y <= 100:
        deg_up["dim"] = 0
        deg_up["low"] = 0
        deg_up["medium"] = 0
        deg_up["high"] = 0
        deg_up["bright"] = 1
    return deg_up
def getMembershipBrightness(z):
    global deg_op
    deg_op = {}
    if z < 0 or z > 100:
        deg_op["dim"] = 0
        deg_op["low"] = 0
        deg_op["medium"] = 0
        deg_op["high"] = 0
        deg_op["bright"] = 0
    elif z >= 0 and z <= 20:
        deg_op["dim"] = 1
        deg_op["low"] = 0
        deg_op["medium"] = 0
        deg_op["high"] = 0
        deg_op["bright"] = 0
    elif z > 20 and z <= 30:
        deg_op["dim"] = float((30 - z) / 10)
        deg_op["low"] = float((z - 20) / 10)
        deg_op["medium"] = 0
        deg_op["high"] = 0
        deg_op["bright"] = 0
    elif z > 30 and z <= 40:
        deg_op["dim"] = 0
        deg_op["low"] = float((40 - z) / 10)
        deg_op["medium"] = float((z - 30) / 5)
        deg_op["high"] = 0
        deg_op["bright"] = 0
    elif z > 40 and z <= 50:
        deg_op["dim"] = 0
        deg_op["low"] = 0
        deg_op["medium"] = float((50 - z) / 10)
        deg_op["high"] = float((z - 40) / 10)
        deg_op["bright"] = 0
    elif z > 50 and z <= 60:
        deg_op["dim"] = 0
        deg_op["low"] = 0
        deg_op["medium"] = 1
        deg_op["high"] = float((z - 50) / 10)
        deg_op["bright"] = 0
    elif z > 60 and z <= 70:
        deg_op["dim"] = 0
        deg_op["low"] = 0
        deg_op["medium"] = float((70 - z) / 10)
        deg_op["high"] = 1
        deg_op["bright"] = 0
    elif z > 70 and z <= 80:
        deg_op["dim"] = 0
        deg_op["low"] = 0
        deg_op["medium"] = 0
        deg_op["high"] = float((80 - z) / 10)
        deg_op["bright"] = float((z - 70) / 10)
    elif z > 80 and z <= 90:
        deg_op["dim"] = 0
        deg_op["low"] = 0
        deg_op["medium"] = 0
        deg_op["high"] = 0
        deg_op["bright"] = float((90 - z) / 10)
    elif z > 90 and z <= 100:
        deg_op["dim"] = 0
        deg_op["low"] = 0
        deg_op["medium"] = 0
        deg_op["high"] = 0
        deg_op["bright"] = 1
    return deg_op
def rule_evaluation(deg_al,deg_up):
    dim = max(min(deg_al["dark"], deg_up["dim"]), min(deg_al["dim"], deg_up["low"]))
    low = min(deg_al["dark"], deg_up["low"])
    medium = min(deg_al["dark"], deg_up["medium"])
    bright = min(deg_al["bright"], deg_up["bright"])
    high=0
    return dim, low, medium, bright,high
def CoG(dim, low, medium, bright,high):
    x=0, y=0
    for i in range(101):
        deg_output = getMembershipBrightness(i)
        brightness = max(min(deg_output["dim"], dim),min(deg_output["low"],low),min(deg_output["medium"],medium),min(deg_output["bright"],bright))
        print(brightness)
        x+=i*brightness
        y+=brightness
    if(y==0):
     y=1
    brightness_level=x/y
    return brightness_level
amb_light = float(input("Ambient Light Level (0 to 500) : "))
user_preference = float(input("User Preference Level (0 to 100) : "))
deg_al=getMembershipLight(amb_light)
deg_up=getMembershipPreference(user_preference)
dim, low, medium, bright,high = rule_evaluation(deg_al,deg_up)
print(dim)
print(low)
print(medium)
print(bright)
print(output=CoG(dim, low, medium, bright,high))
print(output)
